﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FirstMVCWebApp.Models
{
    [Table("StudentDetails")]
    public class StudentDetails
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Name is Required")]
        public string? Name { get; set; }

        public string? Gender { get; set; }

        public string? Course { get; set; }

        public string? RollNo { get; set; }

        public string? Branch { get; set; }

        public string? FatherName { get; set; }

        public string? MotherName { get; set; }

        public int? Semester { get; set; }

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public string? Address { get; set; }

        public string? City { get; set; }

        public int? Marks { get; set; }

        public DateTime? CreatedOn { get; set; }

        public string? CreatedBy { get; set; }

        public DateTime? UpdatedOn { get; set; }

        public string? UpdatedBy { get; set; }

        public bool? ActiveStatus { get; set; }

        
    }
}