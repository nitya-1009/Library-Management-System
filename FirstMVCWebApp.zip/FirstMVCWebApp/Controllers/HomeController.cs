using FirstMVCWebApp.Data;
using FirstMVCWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace FirstMVCWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        [HttpGet]
        public IActionResult StudentRegistration()
        {
            // Creates a SelectList: passing the source list, the value field, and the display text field
            ViewData["CourseList"] = new SelectList(_context.Courses.ToList(), "CourseId", "CourseName");
            return View();
        }

        [HttpPost]
        public IActionResult StudentRegistration(StudentDetails student)
        {
            ModelState.Remove("CreatedOn");
            ModelState.Remove("CreatedBy");
            ModelState.Remove("UpdatedOn");
            ModelState.Remove("UpdatedBy");
            ModelState.Remove("ActiveStatus");

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                ViewBag.Errors = errors;
            }

            if (ModelState.IsValid)
            {
                student.CreatedOn = DateTime.Now;
                student.CreatedBy = "Admin";
                student.UpdatedOn = null;
                student.UpdatedBy = null;
                student.ActiveStatus = true;

                _context.StudentDetails.Add(student);
                _context.SaveChanges();
                return RedirectToAction("StudentRegistration");
            }

            // Reload the SelectList if validation fails
            ViewData["CourseList"] = new SelectList(_context.Courses.ToList(), "CourseId", "CourseName");
            return View(student);
        }
    }
}
